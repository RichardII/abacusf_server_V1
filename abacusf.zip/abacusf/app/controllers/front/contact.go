package front

import (
	"../../models"
	"../../tools/debug"
	"github.com/labstack/echo"
	"net/http"
)

func ContactController(c echo.Context) error {
	debug.Log("front<ContactController>")

	db := models.GetDataBase()
	defer db.Close()
	debug.Log("<%v : db instance close\n", db)

	var site models.Site
	for _, s := range _sites {
		if s.Host == c.Request().Host {
			site = s
		}
	}

	student := models.StudentSession(db, c)

	return c.Render(http.StatusOK, site.Host+"<contact>", map[string]interface{}{
		"title":   site.Title,
		"student": student,
	})
}
